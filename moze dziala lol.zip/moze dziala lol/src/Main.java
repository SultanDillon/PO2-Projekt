import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.swing.*;
        public class Main {
            private static final Logger logger = LogManager.getLogger(WypozyczalniaDVDFrame.class);
            public static void main(String[] args) {
                logger.info("Rozpoczęcie działania aplikacji...");
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        new WypozyczalniaDVDFrame();
                    }
                });
                logger.info("Aplikacja została uruchomiona pomyślnie.");
            }
        }
