package com.example.wypozyczalnia.dvd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WypozyczalniaDvdApplication {

    public static void main(String[] args) {
        SpringApplication.run(WypozyczalniaDvdApplication.class, args);
    }
}
