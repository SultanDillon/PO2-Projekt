package com.example.wypozyczalnia.dvd.service;
import com.example.wypozyczalnia.dvd.model.DVD;
import com.example.wypozyczalnia.dvd.repository.DVDRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RentalService {

    private final DVDRepository dvdRepository;

    public RentalService(DVDRepository dvdRepository) {
        this.dvdRepository = dvdRepository;
    }

    public List<DVD> getAvailableDVDs() {
        return dvdRepository.findAllByAvailableTrue();
    }

    public void rentDVD(Long dvdId) {
        DVD dvd = dvdRepository.findById(dvdId)
                .orElseThrow(() -> new RuntimeException("DVD not found"));
        dvd.setAvailable(false);
        dvdRepository.save(dvd);
    }

    public void addDVD(DVD dvd) {
        dvdRepository.save(dvd);
    }
}
