package com.example.wypozyczalnia.dvd.controller;
import com.example.wypozyczalnia.dvd.model.DVD;
import com.example.wypozyczalnia.dvd.service.RentalService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dvds")
public class DVDController {

    private final RentalService rentalService;

    public DVDController(RentalService rentalService) {
        this.rentalService = rentalService;
    }

    @GetMapping
    public List<DVD> getAvailableDVDs() {
        return rentalService.getAvailableDVDs();
    }

    @PostMapping("/rent/{dvdId}")
    public void rentDVD(@PathVariable Long dvdId) {
        rentalService.rentDVD(dvdId);
    }

    @PostMapping("/add")
    public void addDVD(@RequestBody DVD dvd) {
        rentalService.addDVD(dvd);
    }
}
